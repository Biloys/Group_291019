import { createComments } from "./fetch.js";
const root = document.querySelector("#root");

createComments(root);
